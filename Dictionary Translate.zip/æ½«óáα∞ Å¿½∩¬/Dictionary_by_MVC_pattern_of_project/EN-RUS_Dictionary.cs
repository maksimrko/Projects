﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;


namespace Dictionary_by_MVC_pattern_of_project
{

    class EN_RUS_Dictionary:BaseDictionary
    {
        
        public void MainMenu()
        {
            var isRunning = true;
            do
            {
                //Console.Clear();
                Console.WriteLine("|   Welcome to the dictionary   |\n|   Please select an option:    |");
                Console.WriteLine("|    1. Enter Word              |");
                Console.WriteLine("|    2. Show Word               |");
                Console.WriteLine("|    3. Change Word             |");
                Console.WriteLine("|    4. Delete Word             |");
                Console.WriteLine("|    5. Save Word               |");
                Console.WriteLine("|    6. Load Word               |");
                Console.WriteLine("|    7. Quit                    |");
                Console.WriteLine("----------------------------------");
                var inputMain = Console.ReadLine();
                switch (inputMain)
                {
                    case "1":
                        addWord();
                        Console.WriteLine("Слово было добавлено.Нажмите Enter чтоб продолжить");
                        Console.ReadKey();
                        break;
                    case "2":
                        echoWord();
                        Console.WriteLine("Слово было выведено.Нажмите Enter чтоб продолжить");
                        Console.ReadKey();
                        break;
                    case "3":
                        //Console.Clear();
                        Console.WriteLine("Пожалуйста введите слово{ключ}который вы хотите поменять:");
                        string inputKey = Console.ReadLine();
                        string correctedWord = "";
                        string correctedDefinition = " ";
                        ChangeDefinitionWord(inputKey,correctedWord, correctedDefinition);
                        Console.WriteLine("Слово было изменненно");
                        Console.ReadKey();
                        Console.WriteLine("-----------Слово {ключ} не найдено----------------------");
                        break;
                    case "4":
                        Console.WriteLine("Пожалуйста введите слово{ключ}который вы хотите удалить:");
                        string deleteKey = Console.ReadLine();
                        if (DeleteEntry(deleteKey) == false)
                        {
                            Console.WriteLine("Слово не было найдено");
                        }
                        else
                        {
                            Console.WriteLine("Слово было удаленно.Нажмите Enter чтоб вернуться");
                            Console.ReadKey();
                        }
                       
                        break;
                    case "5":
                        saveToFileENRUS_Dictionary();
                        Console.WriteLine("Слово было сохраненно.Нажмите Enter чтоб продолжить");
                        Console.ReadKey();
                        break;
                    case "6":
                        loadToFileENRUS_Dictionary();
                        Console.WriteLine("Слово было загружено.Нажмите Enter чтоб продолжить");
                        Console.ReadKey();
                        break;
                    case "7":
                        Console.Clear();
                        Console.WriteLine("Quitting.");
                        isRunning = false;
                        break;
                }
            } while (isRunning);
        }

       

    }

    
}

