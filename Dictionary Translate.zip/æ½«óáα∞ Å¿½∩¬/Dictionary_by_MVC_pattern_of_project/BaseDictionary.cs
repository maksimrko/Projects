﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace Dictionary_by_MVC_pattern_of_project
{
   public class BaseDictionary
    {

        public Dictionary<string, string> dict = new XmlSerializableDictionary<string, string>();
        /// <summary>
        /// Удаляет указанный ключ
        /// </summary>
        /// <param name="delKey"></param>
        /// <returns></returns>
        public bool DeleteEntry(string delKey)
        {
            return dict.Remove(delKey);
        }

        /// <summary>
        /// Добавляет слово
        /// </summary>
        public void addWord()
        {
            Console.WriteLine("Введите слово {Ключ}:");
            string key = Console.ReadLine();
            Console.WriteLine("Введите слово {Значение}:");
            string value = Console.ReadLine();
            dict.Add(key, value);

        }

        /// <summary>
        /// Вывод перевода слов
        /// </summary>
        public void echoWord()
        {
            foreach (var pair in this.dict)
            {
                    Console.WriteLine("key = " + pair.Key+"\n"+"Значение = "+ pair.Value);
            }

        }
        /// <summary>
        /// Изменить Слово
        /// </summary>
        /// <param name="inputKey"></param>
        /// <param name="correctedWord"></param>
        /// <param name="correctedDefinition"></param>
        public void ChangeDefinitionWord(string inputKey, string correctedWord, string correctedDefinition)
        {
            if (correctedDefinition == "")
            {
                Console.WriteLine("Значение не было найдено,увы.");
            }
            else
            {
                if (DeleteEntry(inputKey))
                {
                    if (correctedWord == "")
                    {
                        addWord();
                    }
                    else
                    {
                        Console.WriteLine("Слово не найдено");
                        //addWord();
                    }
                }
            }
        }


        /// <summary>
        /// Загрузить из файла Англо-Русский словарь
        /// </summary>
        public void loadToFileENRUS_Dictionary()
        {
            using (FileStream fs = new FileStream(@"DictionaryENG_RUS.xml", FileMode.Open))
            {
                System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(XmlSerializableDictionary<string, string>));
                XmlSerializableDictionary<string, string> dict = (XmlSerializableDictionary<string, string>)serializer.Deserialize(fs);

                foreach (KeyValuePair<string, string> kvp in dict)
                {
                    Console.WriteLine(kvp.Key + " " + kvp.Value);
                }

                Console.WriteLine("Объект востановлен");

            }
        }
        /// <summary>
        /// Загрузить из файла Русско-Англо словарь
        /// </summary>
        public void loadToFileRUSEN_Dictionary()
        {
            using (FileStream fs = new FileStream(@"DictionaryRus_ENG.xml", FileMode.Open))
            {
                System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(XmlSerializableDictionary<string, string>));
                XmlSerializableDictionary<string, string> dict = (XmlSerializableDictionary<string, string>)serializer.Deserialize(fs);

                foreach (KeyValuePair<string, string> kvp in dict)
                {
                    Console.WriteLine(kvp.Key + " " + kvp.Value);
                }

                Console.WriteLine("Объект востановлен");

            }
        }
        /// <summary>
        /// Сохранить в файл Англо-Русский словарь
        /// </summary>
        public void saveToFileENRUS_Dictionary()
        {
            System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(XmlSerializableDictionary<string, string>));
            // сериализация
            using (System.IO.StreamWriter writer = new System.IO.StreamWriter(@"DictionaryEng_Rus.xml"))
            {
                serializer.Serialize(writer, dict);
                Console.WriteLine("Объект Dictionary<string,string Serialize");
            }
        }



        /// <summary>
        /// Сохранить в файл Русско-Англо словарь
        /// </summary>
        public void saveToFileRUSEN_Dictionary()
        {
            System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(XmlSerializableDictionary<string, string>));
            // сериализация
            using (System.IO.StreamWriter writer = new System.IO.StreamWriter(@"DictionaryRUS_ENG.xml"))
            {
                serializer.Serialize(writer, dict);
                Console.WriteLine("Объект Dictionary<string,string Serialize");
            }
        }




        /// <summary>
        /// Для запись в xml формат коллекцию Dictionary
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        [XmlRoot("Dictionary")]
        public class XmlSerializableDictionary<TKey, TValue> : Dictionary<TKey, TValue>, IXmlSerializable
        {
            public System.Xml.Schema.XmlSchema GetSchema()
            {
                return null;
            }

            public void ReadXml(System.Xml.XmlReader reader)
            {
                XmlSerializer keySerializer = new XmlSerializer(typeof(TKey));
                XmlSerializer valueSerializer = new XmlSerializer(typeof(TValue));
                bool wasEmpty = reader.IsEmptyElement;
                reader.Read();
                if (wasEmpty)
                    return;
                while (reader.NodeType != System.Xml.XmlNodeType.EndElement)
                {
                    reader.ReadStartElement("item");
                    reader.ReadStartElement("key");
                    TKey key = (TKey)keySerializer.Deserialize(reader);
                    reader.ReadEndElement();
                    reader.ReadStartElement("value");
                    TValue value = (TValue)valueSerializer.Deserialize(reader);
                    reader.ReadEndElement();
                    this.Add(key, value);
                    reader.ReadEndElement();
                    reader.MoveToContent();
                }
                reader.ReadEndElement();
            }

            public void WriteXml(System.Xml.XmlWriter writer)
            {
                XmlSerializer keySerializer = new XmlSerializer(typeof(TKey));
                XmlSerializer valueSerializer = new XmlSerializer(typeof(TValue));
                foreach (TKey key in this.Keys)
                {
                    writer.WriteStartElement("item");
                    writer.WriteStartElement("key");
                    keySerializer.Serialize(writer, key);
                    writer.WriteEndElement();
                    writer.WriteStartElement("value");
                    TValue value = this[key];
                    valueSerializer.Serialize(writer, value);
                    writer.WriteEndElement();
                    writer.WriteEndElement();
                }
            }
        }



    }
}