﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paint
{
    class ModelUndoRedoPictureBox
    {
        public bool canUndo;
        public bool canRedo;
        private List<Image> img;
        private int ptrImg;

        #region Singleton
        private static ModelUndoRedoPictureBox instance;
        private ModelUndoRedoPictureBox()
        {
            img = new List<Image>();
            canUndo = false;
            canRedo = true;
        }

        /// <summary>
        /// Возвращает модель для дальнейшей работы с данными
        /// </summary>
        public static ModelUndoRedoPictureBox getInstance()
        {
            if (instance == null)
                instance = new ModelUndoRedoPictureBox();
            return instance;
        }

        #endregion


        public void put(Image i)
        {
            if (this.ptrImg != this.img.Count - 1)
            {
                this.img.RemoveRange(this.ptrImg, this.img.Count - this.ptrImg);
            }
            this.img.Add((Image)i.Clone());
            this.ptrImg++;

            this.canUndo = true;
            this.canRedo = false;

        }

        public Image getUndo()
        {
            if (this.ptrImg == 0)
            {
                this.canUndo = false;
                return this.img[0];
            }
            else
            {
                this.ptrImg--;
                this.canUndo = true;

                return this.img[this.ptrImg];
            }
        }

        public Image getRedo()
        {
            if (this.ptrImg + 1 >= this.img.Count)
            {
                this.canRedo = false;

                return this.img[this.img.Count - 1];
            }
            else
            {
                this.ptrImg++;
                this.canRedo = true;

                return this.img[this.ptrImg];
            }
        }
    }
}



