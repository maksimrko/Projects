﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections.Generic;
using System.Windows.Forms;



namespace Paint
{
    public partial class Paint : Form
    {
        Color penColor = Color.Black;//Color pen of standart black
        bool IsEraser = false;
        Point Eras=new Point ();//Eraser

        float penSize = 2;//Size pen =2
        List<Point> p;//List Point for consturt traingle
        int flag;//checking about flag print triangle


        Point lastPoint; //Last point drawn through coordinates

        Point currentPoint;//Start point drawn through coordinates

        Rectangle rect;//announcement rectangle

        bool brushActive = false;//announcement drawing brush
        bool rectActive = false;// announcement drawing rectangle 
        bool ellipseActive = false;//announcement drawing  ellipse
        bool drawMode = false;//announcement drawing 

        Bitmap image; //announcement Gdi+

        int? selectedColorIndexBackup;//selected color through index
        int? selectedSizeBackup;//selected size picture box
       

        public Paint()
        {
            InitializeComponent();
            InitializeForm();
            flag = 0;
           
        }
        /// <summary>
        /// InitializeForm and activity draw brush,rectangle and ellipse
        /// </summary>
        private void InitializeForm()
        {
            chosenColor.Image = new Bitmap(20, 20);

            IniatializeGroupBox();
            InitializeImage();

            if (selectedSizeBackup.HasValue)
                sizeSelector.SelectedIndex = selectedSizeBackup.Value;
            else
                sizeSelector.SelectedIndex = 1;

            brushButton.Checked = brushActive;
            rectButton.Checked = rectActive;
            ellipseButton.Checked = ellipseActive;
          
        }
        /// <summary>
        /// Choosing color on figures
        /// </summary>
        /// <param name="c"></param>
        private void ChooseColor(Color c)
        {
            using (Graphics g = Graphics.FromImage(chosenColor.Image))
            using (Brush b = new SolidBrush(c))
            {
                g.FillRectangle(b, new Rectangle(0, 0, 20, 20));
                Refresh();
               
            }
        }
        /// <summary>
        /// InitializeImage
        /// </summary>
        private void InitializeImage()
        {
            if (image == null)
            {
                image = new Bitmap(pictureBox.Width, pictureBox.Height);
                using (Graphics g = Graphics.FromImage(image))
                   g.Clear(Color.White);
                
            }
            pictureBox.Image = image;
          
        }
        
        /// <summary>
        /// IniatializeGroupBox where is picture box and color selector
        /// </summary>
        void IniatializeGroupBox()
        {
            foreach (KnownColor x in Enum.GetValues(typeof(KnownColor)))
            {
                PictureBox box = new PictureBox();
                box.Size = new Size(25, 25);
                colorSelector.Controls.Add(box);
                box.BackColor = Color.FromKnownColor(x);
                box.Click += ChoosePenColor;
                
            }
            if (selectedColorIndexBackup.HasValue)
            {
                ChoosePenColor(colorSelector.Controls[selectedColorIndexBackup.Value], new EventArgs());
                
            }
            else
            {
                ChooseColor(Color.Black);
                
            }
        }
        /// <summary>
        /// ChoosePenColor by index and assigned to picturebox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ChoosePenColor(object sender, EventArgs e)
        {
            PictureBox box = (sender as PictureBox);

            if (selectedColorIndexBackup.HasValue)
            {
                (colorSelector.Controls[selectedColorIndexBackup.Value] as PictureBox).Image?.Dispose();
                (colorSelector.Controls[selectedColorIndexBackup.Value] as PictureBox).Image = null;
            }

            selectedColorIndexBackup = colorSelector.Controls.IndexOf(box);
            penColor = box.BackColor;
            ChooseColor(penColor);

            box.Image = new Bitmap(box.Width, box.Height);

            using (Pen p = new Pen(Color.FromArgb(255 - penColor.R, 255 - penColor.B, 255 - penColor.B), 4))
            using (Graphics g = Graphics.FromImage(box.Image))
            {
                p.DashPattern = new float[] { 1F, 1F };
                g.DrawRectangle(p, new Rectangle(0, 0, (sender as PictureBox).Width, (sender as PictureBox).Height));

            }
        }
        /// <summary>
        /// Mouse down on picture box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (IsEraser == true)
            {
                Eras.X = e.X;
                Eras.Y = e.Y;
                
            }
            if (!brushActive && !rectActive && !ellipseActive) return;

            if (e.Button == MouseButtons.Left)
            {
                lastPoint = e.Location;
                BeginDrawing();
            }

            if (e.Button == MouseButtons.Right)
            {
                CancelDrawing();
            }
            
        }
        /// <summary>
        /// Mouse Up on picture box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                CancelDrawing();
            }
        }
        /// <summary>
        /// Activation draw
        /// </summary>
        private void BeginDrawing()
        {
            drawMode = true;
          
        }
        /// <summary>
        /// Cancel draw
        /// </summary>
        private void CancelDrawing()
        {
            pictureBox.Invalidate();
            drawMode = false;
            if (rectActive || ellipseActive)
            {
                using (Graphics g = Graphics.FromImage(image))
                using (Pen pen = new Pen(penColor, penSize))
                {
                    g.SmoothingMode =
                        System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                    pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                   
                    if (rectActive)
                    {
                        g.DrawRectangle(pen, rect);
                        rectActive = false;
                        
                    }

                    if (ellipseActive)
                    {
                        g.DrawEllipse(pen, rect);
                        ellipseActive = false;
                       
                    }
                }
            }
        }
        /// <summary>
        /// Mouse Move on picture box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (IsEraser == true)
            {
                using (Graphics g = Graphics.FromImage(image))
                {
                    g.DrawLine(new Pen(Color.White, 10), Eras,e.Location);
                    Eras = e.Location;
                }
                pictureBox.Invalidate();

            }
            if (!drawMode) return;

            currentPoint = e.Location;

            if (brushActive)
            {
                using (Pen pen = new Pen(penColor, penSize))
                using (Graphics g = Graphics.FromImage(image))
                {
                    pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                    pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                    g.SmoothingMode =
                        System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    g.DrawLine(pen, lastPoint, currentPoint);
                    lastPoint = currentPoint;
                   
                }
            }
            else if (rectActive || ellipseActive)
            {
                int x = Math.Min(lastPoint.X, e.X);
                int y = Math.Min(lastPoint.Y, e.Y);

                int width = Math.Max(lastPoint.X, e.X) - Math.Min(lastPoint.X, e.X);

                int height = Math.Max(lastPoint.Y, e.Y) - Math.Min(lastPoint.Y, e.Y);
                rect = new Rectangle(x, y, width, height);
               pictureBox.Refresh();
            }
         
            pictureBox.Image = image;
            
        }
        /// <summary>
        /// Event save project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveButton_Click(object sender, EventArgs e)
        {
            if (saveFileDialog.ShowDialog() != DialogResult.OK)
                return;

            ImageFormat format = ImageFormat.Bmp;
            image.Save(saveFileDialog.FileName, format);
        }
        /// <summary>
        /// Changed size picture box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox_SizeChanged(object sender, EventArgs e)
        {
            Bitmap newImage = new Bitmap(pictureBox.Width, pictureBox.Height);
            newImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);
            using (Graphics g = Graphics.FromImage(newImage))
            {
               // g.Clear(Color.Black);
                g.DrawImageUnscaled(image, new Point(0, 0));
            }
            image.Dispose();
            image = newImage;
            pictureBox.Image = image;
        }
        /// <summary>
        /// Event load project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loadButton_Click(object sender, EventArgs e)
        {
            pictureBox.CreateGraphics().Clear(Color.White);
            rect = new Rectangle();

            pictureBox.Invalidate();
            if (openFileDialog.ShowDialog() != DialogResult.OK)
                return;

            int oldImageHeight = pictureBox.Image.Height;
            int oldImageWidth = pictureBox.Image.Width;

            image?.Dispose();
            image = Image.FromFile(openFileDialog.FileName) as Bitmap;

            ClientSize = new Size((int)(ClientSize.Width - oldImageWidth * 1.11 + image.Width * 1.11),
                ClientSize.Height - oldImageHeight + image.Height);

            pictureBox.Image = image;
        }

        /// <summary>
        /// Event click for start draw brush
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void brushButton_Click(object sender, EventArgs e)
        {
            brushActive = brushButton.Checked = !brushActive;
            ellipseActive = ellipseButton.Checked = false;
            rectActive = rectButton.Checked = false;     
            
        }
        /// <summary>
        /// Event click for start draw rectangle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rectButton_Click(object sender, EventArgs e)
        {
            brushActive = brushButton.Checked = false;
            ellipseActive = ellipseButton.Checked = false;
            rectActive = rectButton.Checked = !rectActive;           
        }
        /// <summary>
        /// Event click for start draw ellipse
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ellipseButton_Click(object sender, EventArgs e)
        {
            brushActive = brushButton.Checked = false;
            ellipseActive = ellipseButton.Checked = !ellipseActive;
            rectActive = rectButton.Checked = false;

        }

        /// <summary>
        /// Event click for start draw triangle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void triangle_Click(object sender, EventArgs e)
        {
            if (flag != 0)
            {
                return;
            }
            else
            {
                flag = 2;
                toolStripButton2.BackColor = Color.Black;
                ModelUndoRedoPictureBox.getInstance().put(pictureBox.Image);
                CheckUndoRedo();
                this.p = new List<Point>();
            }
        }

        /// <summary>
        /// Checking UndoRedo
        /// </summary>
        private void CheckUndoRedo()
        {
            if (ModelUndoRedoPictureBox.getInstance().canUndo)
            {
                Undo.Enabled = true;
            }
            if (ModelUndoRedoPictureBox.getInstance().canRedo)
            {
                Redo.Enabled = true;
            }

        }
        /// <summary>
        /// Button Undo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Undo_Click(object sender, EventArgs e)
        {
            pictureBox.Image = ModelUndoRedoPictureBox.getInstance().getUndo();
            pictureBox.Refresh();
            Refresh();
            CheckUndoRedo();
        }
        /// <summary>
        /// Button Redo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Redo_Click(object sender, EventArgs e)
        {
            pictureBox.Image = ModelUndoRedoPictureBox.getInstance().getRedo();
            pictureBox.Refresh();
            Refresh();
            CheckUndoRedo();

        }

        /// <summary>
        /// Drawing by picture box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox_Paint(object sender, PaintEventArgs e)
        {
            if (!drawMode)
                return;

            e.Graphics.SmoothingMode =
                System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            using (Pen pen = new Pen(penColor, penSize))
            {
                pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                if (rectActive)
                    e.Graphics.DrawRectangle(pen, rect);
                if (ellipseActive)
                    e.Graphics.DrawEllipse(pen, rect);

            }
        }
        /// <summary>
        /// Clear picture box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void clearButton_Click(object sender, EventArgs e)
        {
            image?.Dispose();
            image = null;
            InitializeImage();
        }
        /// <summary>
        /// Selecter choose size figure
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void sizeSelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (sizeSelector.SelectedIndex)
            {
                case 0:
                    penSize = 1;
                    break;
                case 1:
                    penSize = 3;
                    break;
                case 2:
                    penSize = 6;
                    break;
                case 3:
                    penSize = 9;
                    break;
               
            }
        }



        /// <summary>
        /// Refresh all settings project
        /// </summary>
        private void RefreshAllControls()
        {
            selectedSizeBackup = sizeSelector.SelectedIndex;
            Hide();
            InitializeForm();
            Show();
            
        }
        /// <summary>
        /// Button exit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// Printing document
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap myBitmap1 = new Bitmap(pictureBox.Width, pictureBox.Height);
            pictureBox.DrawToBitmap(myBitmap1, new Rectangle(0, 0, pictureBox.Width, pictureBox.Height));
            e.Graphics.DrawImage(myBitmap1, 0, 0);
            myBitmap1.Dispose();
        }
        /// <summary>
        /// Button PrintDialog
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            System.Drawing.Printing.PrintDocument myPrintDocument1 = new System.Drawing.Printing.PrintDocument();
            PrintDialog myPrinDialog1 = new PrintDialog();
            myPrintDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(printDocument_PrintPage);
            myPrinDialog1.Document = myPrintDocument1;
            if (myPrinDialog1.ShowDialog() == DialogResult.OK)
            {
                myPrintDocument1.Print();
            }
        }
        /// <summary>
        /// Drawing poligon
        /// </summary>
        private void drwPoligon()
        {
            flag = 0;
            toolStripButton2.BackColor = Color.Gray;

            // Graphics g = Graphics.FromImage(image);
            Graphics g = Graphics.FromImage(pictureBox.Image);

            // Create pen.
            Pen blackPen = new Pen(Color.Black, 3);
            SolidBrush whiteBrush = new SolidBrush(Color.White);


            Point[] curvePoints = new Point[p.Count];
            p.CopyTo(curvePoints);


            // Draw polygon to screen.
            g.DrawPolygon(blackPen, curvePoints);
            g.FillPolygon(whiteBrush, curvePoints);

            Refresh();
            pictureBox.Refresh();

            toolStripButton2.Text = "Start";


        }
        /// <summary>
        /// Mouse click at picture box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox_MouseClick_1(object sender, MouseEventArgs e)
        {
            switch (flag)
            {
                case 1:
                    p.Add(new Point(e.X, e.Y));
                    toolStripButton2.Text = " " + p.Count + " ";
                    break;

                case 2:
                    p.Add(new Point(e.X, e.Y));
                    toolStripButton2.Text = " " + p.Count + " ";
                    if (p.Count > 2)
                    {
                        drwPoligon();
                    }
                    break;
            }
        }
        /// <summary>
        /// About Program
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton3_Click_1(object sender, EventArgs e)
        {
            var f = new AboutProgram();
            f.ShowDialog();
        }
        /// <summary>
        /// PrintPreview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            var pr = new PrintPreviewDialog();
            pr.Document = printDocument;
            pr.Show();

        }
        /// <summary>
        /// Eraser for PictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Eraser_Click(object sender, EventArgs e)
        {
            if (IsEraser)
            {
                IsEraser = false;
            }
            else
            {
                IsEraser = true;
            }
            MessageBox.Show(IsEraser.ToString());
        }
    }
}
